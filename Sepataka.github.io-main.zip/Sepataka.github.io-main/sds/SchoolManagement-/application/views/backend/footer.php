<!-- Footer -->
<footer class="main">
	&copy; <?php echo date('Y')?>  |
    <strong>Developed by Academic Student Support System</strong>
</footer>
